package com.ollie.client.module;

public abstract class Setting<T> {

    public final String name;
    public T value;

    protected Setting(String name, T value) {
        this.name = name;
        this.value = value;
    }

    public abstract String display();

    public static final class Bool extends Setting<Boolean> {
        public Bool(String name, boolean value) {
            super(name, value);
        }

        @Override
        public String display() {
            return value ? "ON" : "OFF";
        }
    }

    public static final class Num extends Setting<Float> {
        public final float min;
        public final float max;

        public Num(String name, float value, float min, float max) {
            super(name, value);
            this.min = min;
            this.max = max;
        }

        @Override
        public String display() {
            return String.format("%.2f", value);
        }
    }

    public static final class Mode extends Setting<String> {
        public final String[] options;

        public Mode(String name, String value, String... options) {
            super(name, value);
            this.options = options;
        }

        public void next() {
            for (int i = 0; i < options.length; i++) {
                if (options[i].equals(value)) {
                    value = options[(i + 1) % options.length];
                    return;
                }
            }
            value = options[0];
        }

        @Override
        public String display() {
            return value;
        }
    }

    public static final class Key extends Setting<Integer> {
        public Key(String name, int value) {
            super(name, value);
        }

        public void set(int key) {
            value = key;
        }

        @Override
        public String display() {
            return value == 0 ? "NONE" : org.lwjgl.input.Keyboard.getKeyName(value);
        }
    }
}
