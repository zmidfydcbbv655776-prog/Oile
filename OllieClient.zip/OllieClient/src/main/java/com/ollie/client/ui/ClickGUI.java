package com.ollie.client.ui;

import com.ollie.client.OllieClient;
import com.ollie.client.module.Category;
import com.ollie.client.module.Module;
import com.ollie.client.module.Setting;
import com.ollie.client.util.RenderUtils;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ClickGUI extends GuiScreen {

    private static final int ACCENT = 0xFFB478FF;
    private static final int PANEL = 0xFF121218;
    private static final int PANEL_LIGHT = 0xFF1A1A23;
    private static final int TEXT = 0xFFE8E8F0;
    private static final int SUBTEXT = 0xFF7A7A8C;

    private Category category = Category.COMBAT;
    private Module selected;
    private Setting<?> draggingSetting;

    private float openProgress;
    private long lastFrame;
    private int scroll;

    @Override
    public void initGui() {
        openProgress = 0f;
        lastFrame = System.currentTimeMillis();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        long now = System.currentTimeMillis();
        float delta = Math.min(0.05f, (now - lastFrame) / 1000f);
        lastFrame = now;
        openProgress = Math.min(1f, openProgress + delta * 6f);

        drawGradientRect(0, 0, width, height, 0xCC050508, 0xEE0A0A10);

        float panelW = 580f;
        float panelH = 360f;
        float px = (width - panelW) / 2f;
        float py = (height - panelH) / 2f + (1f - openProgress) * 18f;

        RenderUtils.roundedRect(px, py, panelW, panelH, 10f, PANEL);
        RenderUtils.outline(px, py, panelW, panelH, 0xFF2A2A38);

        drawHeader(px, py, panelW);

        drawCategories(mouseX, mouseY, px + 14f, py + 58f, 116f);
        drawModuleList(mouseX, mouseY, px + 146f, py + 58f, 240f, panelH - 72f);
        drawSettings(mouseX, mouseY, px + 400f, py + 58f, panelW - 414f, panelH - 72f);
    }

    private void drawHeader(float x, float y, float w) {
        RenderUtils.roundedRect(x + 14f, y + 14f, 26f, 26f, 6f, ACCENT);
        mc.fontRendererObj.drawStringWithShadow("o", x + 23f, y + 23f, 0xFF0A0A0F);

        mc.fontRendererObj.drawStringWithShadow("OLLIE", x + 48f, y + 18f, TEXT);
        mc.fontRendererObj.drawStringWithShadow("CLIENT 1.8.9", x + 48f, y + 31f, SUBTEXT);

        String hint = "RSHIFT";
        int hintW = mc.fontRendererObj.getStringWidth(hint);
        RenderUtils.roundedRect(x + w - hintW - 30f, y + 18f, hintW + 16f, 16f, 4f, PANEL_LIGHT);
        mc.fontRendererObj.drawStringWithShadow(hint, x + w - hintW - 22f, y + 22f, SUBTEXT);

        RenderUtils.rect(x + 14f, y + 50f, w - 28f, 1f, 0xFF2A2A38);
    }

    private void drawCategories(int mouseX, int mouseY, float x, float y, float w) {
        float itemY = y;
        for (Category cat : Category.values()) {
            boolean hovered = mouseX >= x && mouseX <= x + w && mouseY >= itemY && mouseY <= itemY + 28f;
            boolean active = cat == category;

            if (active) {
                RenderUtils.roundedRect(x, itemY, w, 28f, 6f, PANEL_LIGHT);
                RenderUtils.rect(x, itemY + 6f, 3f, 16f, ACCENT);
            } else if (hovered) {
                RenderUtils.roundedRect(x, itemY, w, 28f, 6f, 0x331A1A23);
            }

            int color = active ? TEXT : hovered ? 0xFFB8B8C8 : SUBTEXT;
            mc.fontRendererObj.drawStringWithShadow(cat.label, x + 14f, itemY + 10f, color);
            itemY += 32f;
        }
    }

    private void drawModuleList(int mouseX, int mouseY, float x, float y, float w, float h) {
        RenderUtils.roundedRect(x, y, w, h, 8f, PANEL_LIGHT);
        RenderUtils.outline(x, y, w, h, 0xFF2A2A38);

        List<Module> modules = new ArrayList<>(OllieClient.moduleManager.byCategory(category));
        float rowH = 30f;
        float contentH = modules.size() * rowH + 6f;
        int maxScroll = Math.max(0, (int) (contentH - h + 8f));
        scroll = Math.max(0, Math.min(scroll, maxScroll));

        RenderUtils.scissor(x + 2f, y + 2f, w - 4f, h - 4f);

        float rowY = y + 6f - scroll;
        for (Module module : modules) {
            boolean hovered = mouseX >= x + 6f && mouseX <= x + w - 6f
                && mouseY >= rowY && mouseY <= rowY + rowH - 4f;

            if (module == selected) {
                RenderUtils.roundedRect(x + 6f, rowY, w - 12f, rowH - 4f, 5f, 0x44B478FF);
            } else if (hovered) {
                RenderUtils.roundedRect(x + 6f, rowY, w - 12f, rowH - 4f, 5f, 0x22FFFFFF);
            }

            int nameColor = module.enabled ? ACCENT : TEXT;
            mc.fontRendererObj.drawStringWithShadow(module.name, x + 16f, rowY + 7f, nameColor);

            String state = module.enabled ? "ON" : "OFF";
            int stateW = mc.fontRendererObj.getStringWidth(state);
            int stateColor = module.enabled ? ACCENT : SUBTEXT;
            mc.fontRendererObj.drawStringWithShadow(state, x + w - stateW - 16f, rowY + 7f, stateColor);

            rowY += rowH;
        }

        RenderUtils.endScissor();

        if (modules.isEmpty()) {
            mc.fontRendererObj.drawStringWithShadow("No modules", x + 14f, y + 14f, SUBTEXT);
        }
    }

    private void drawSettings(int mouseX, int mouseY, float x, float y, float w, float h) {
        RenderUtils.roundedRect(x, y, w, h, 8f, PANEL_LIGHT);
        RenderUtils.outline(x, y, w, h, 0xFF2A2A38);

        if (selected == null) {
            mc.fontRendererObj.drawStringWithShadow("Select a module", x + 14f, y + 14f, SUBTEXT);
            return;
        }

        RenderUtils.scissor(x + 2f, y + 2f, w - 4f, h - 4f);

        mc.fontRendererObj.drawStringWithShadow(selected.name, x + 14f, y + 12f, TEXT);
        mc.fontRendererObj.drawStringWithShadow(selected.description, x + 14f, y + 26f, SUBTEXT);

        float rowY = y + 46f;
        float rowW = w - 28f;

        for (Setting<?> setting : selected.settings) {
            mc.fontRendererObj.drawStringWithShadow(setting.name, x + 14f, rowY, 0xFFB8B8C8);

            if (setting instanceof Setting.Bool) {
                Setting.Bool bool = (Setting.Bool) setting;
                float toggleX = x + w - 48f;
                float toggleY = rowY - 2f;
                RenderUtils.roundedRect(toggleX, toggleY, 30f, 14f, 7f, bool.value ? ACCENT : 0xFF2A2A38);
                float knobX = bool.value ? toggleX + 17f : toggleX + 3f;
                RenderUtils.roundedRect(knobX, toggleY + 3f, 8f, 8f, 4f, 0xFFFFFFFF);
            } else if (setting instanceof Setting.Num) {
                Setting.Num num = (Setting.Num) setting;
                float barX = x + 14f;
                float barY = rowY + 14f;
                RenderUtils.roundedRect(barX, barY, rowW, 4f, 2f, 0xFF2A2A38);
                float progress = (num.value - num.min) / (num.max - num.min);
                RenderUtils.roundedRect(barX, barY, rowW * progress, 4f, 2f, ACCENT);

                String display = num.display();
                int displayW = mc.fontRendererObj.getStringWidth(display);
                mc.fontRendererObj.drawStringWithShadow(display, x + w - displayW - 14f, rowY, SUBTEXT);
                rowY += 12f;
            } else if (setting instanceof Setting.Mode) {
                Setting.Mode mode = (Setting.Mode) setting;
                String display = mode.display();
                int displayW = mc.fontRendererObj.getStringWidth(display);
                RenderUtils.roundedRect(x + w - displayW - 26f, rowY - 3f, displayW + 12f, 14f, 4f, 0xFF2A2A38);
                mc.fontRendererObj.drawStringWithShadow(display, x + w - displayW - 20f, rowY, ACCENT);
            } else if (setting instanceof Setting.Key) {
                Setting.Key key = (Setting.Key) setting;
                String display = key.display();
                int displayW = mc.fontRendererObj.getStringWidth(display);
                RenderUtils.roundedRect(x + w - displayW - 26f, rowY - 3f, displayW + 12f, 14f, 4f, 0xFF2A2A38);
                mc.fontRendererObj.drawStringWithShadow(display, x + w - displayW - 20f, rowY, TEXT);
            }
            rowY += 28f;
        }
        RenderUtils.endScissor();
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        float panelW = 580f;
        float panelH = 360f;
        float px = (width - panelW) / 2f;
        float py = (height - panelH) / 2f;

        float sidebarX = px + 14f;
        float sidebarY = py + 58f;
        float sidebarW = 116f;

        for (Category cat : Category.values()) {
            if (mouseX >= sidebarX && mouseX <= sidebarX + sidebarW
                && mouseY >= sidebarY && mouseY <= sidebarY + 28f) {
                category = cat;
                selected = null;
                scroll = 0;
                return;
            }
            sidebarY += 32f;
        }

        float listX = px + 146f;
        float listY = py + 58f;
        float listW = 240f;

        List<Module> modules = OllieClient.moduleManager.byCategory(category);
        float rowH = 30f;
        float rowY = listY + 6f - scroll;

        for (Module module : modules) {
            if (mouseX >= listX + 6f && mouseX <= listX + listW - 6f
                && mouseY >= rowY && mouseY <= rowY + rowH - 4f) {
                if (mouseButton == 0) module.toggle();
                selected = module;
                return;
            }
            rowY += rowH;
        }

        if (selected != null) {
            float settingsX = px + 400f;
            float settingsY = py + 58f;
            float settingsW = panelW - 414f;
            float rowW = settingsW - 28f;
            float settingY = settingsY + 46f;

            for (Setting<?> setting : selected.settings) {
                if (setting instanceof Setting.Bool) {
                    Setting.Bool bool = (Setting.Bool) setting;
                    float toggleX = settingsX + settingsW - 48f;
                    float toggleY = settingY - 2f;
                    if (mouseX >= toggleX && mouseX <= toggleX + 30f
                        && mouseY >= toggleY && mouseY <= toggleY + 14f) {
                        bool.value = !bool.value;
                        return;
                    }
                } else if (setting instanceof Setting.Num) {
                    Setting.Num num = (Setting.Num) setting;
                    float barX = settingsX + 14f;
                    float barY = settingY + 14f;
                    if (mouseX >= barX && mouseX <= barX + rowW
                        && mouseY >= barY - 4f && mouseY <= barY + 8f) {
                        draggingSetting = num;
                        updateSlider(num, mouseX, barX, rowW);
                        return;
                    }
                    settingY += 12f;
                } else if (setting instanceof Setting.Mode) {
                    if (mouseX >= settingsX + 14f && mouseX <= settingsX + settingsW - 14f
                        && mouseY >= settingY - 4f && mouseY <= settingY + 12f) {
                        ((Setting.Mode) setting).next();
                        return;
                    }
                } else if (setting instanceof Setting.Key) {
                    if (mouseX >= settingsX + 14f && mouseX <= settingsX + settingsW - 14f
                        && mouseY >= settingY - 4f && mouseY <= settingY + 12f) {
                        ((Setting.Key) setting).set(Keyboard.getEventKey() == 0 ? -1 : Keyboard.getEventKey());
                        return;
                    }
                }
                settingY += 28f;
            }
        }

        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        if (draggingSetting instanceof Setting.Num) {
            float panelW = 580f;
            float px = (width - panelW) / 2f;
            updateSlider((Setting.Num) draggingSetting, mouseX, px + 400f + 14f, panelW - 414f - 28f);
        }
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        draggingSetting = null;
        super.mouseReleased(mouseX, mouseY, state);
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int wheel = Mouse.getEventDWheel();
        if (wheel != 0) {
            scroll -= Integer.signum(wheel) * 24;
            scroll = Math.max(0, scroll);
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == Keyboard.KEY_ESCAPE || keyCode == Keyboard.KEY_RSHIFT) {
            mc.displayGuiScreen(null);
            return;
        }
        super.keyTyped(typedChar, keyCode);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    private void updateSlider(Setting.Num setting, int mouseX, float barX, float barW) {
        float progress = (mouseX - barX) / barW;
        progress = Math.max(0f, Math.min(1f, progress));
        setting.value = setting.min + (setting.max - setting.min) * progress;
    }
}
