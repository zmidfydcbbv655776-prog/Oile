package com.ollie.client.mixin;

import com.ollie.client.modules.Modules;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(NetworkManager.class)
public class MixinNetworkManager {

    @Inject(method = "sendPacket", at = @At("HEAD"), cancellable = true)
    private void ollie$cancelPacket(Packet<?> packet, CallbackInfo ci) {
        if (Modules.PacketManipulation.shouldCancel(packet)) {
            ci.cancel();
        }
    }
}
