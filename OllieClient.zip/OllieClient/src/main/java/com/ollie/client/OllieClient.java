package com.ollie.client;

import com.ollie.client.module.Module;
import com.ollie.client.module.ModuleManager;
import com.ollie.client.ui.ClickGUI;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

@Mod(
    modid = OllieClient.MODID,
    name = OllieClient.NAME,
    version = OllieClient.VERSION,
    acceptedMinecraftVersions = "[1.8.9]"
)
public class OllieClient {

    public static final String MODID = "ollieclient";
    public static final String NAME = "Ollie Client";
    public static final String VERSION = "1.0";

    @Mod.Instance(MODID)
    public static OllieClient instance;

    public static ModuleManager moduleManager;
    public static ClickGUI clickGUI;

    private final boolean[] keyStates = new boolean[256];

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        moduleManager = new ModuleManager();
        clickGUI = new ClickGUI();
        MinecraftForge.EVENT_BUS.register(new InputHandler());
    }

    public static Minecraft mc() {
        return Minecraft.getMinecraft();
    }

    public static boolean isEnabled(String moduleName) {
        if (moduleManager == null) return false;
        Module m = moduleManager.get(moduleName);
        return m != null && m.enabled;
    }

    private final class InputHandler {

        @SubscribeEvent
        public void onClientTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END) return;
            Minecraft mc = mc();

            if (mc.currentScreen == null) {
                if (down(Keyboard.KEY_RSHIFT) && !keyStates[Keyboard.KEY_RSHIFT]) {
                    mc.displayGuiScreen(clickGUI);
                }
                for (Module module : moduleManager.modules) {
                    if (module.key == 0) continue;
                    if (down(module.key) && !keyStates[module.key]) {
                        module.toggle();
                    }
                }
            }

            for (int i = 0; i < keyStates.length; i++) {
                keyStates[i] = down(i);
            }
        }

        private boolean down(int key) {
            return key > 0 && key < 256 && Keyboard.isKeyDown(key);
        }
    }
}
