package com.ollie.client.module;

import com.ollie.client.modules.Modules;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {

    public final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        register(new Modules.Aimbot());
        register(new Modules.AutoClicker());
        register(new Modules.Velocity());
        register(new Modules.Reach());
        register(new Modules.Criticals());
        register(new Modules.AntiBot());

        register(new Modules.Speed());
        register(new Modules.LongJump());
        register(new Modules.HighJump());
        register(new Modules.Flight());
        register(new Modules.NoFall());
        register(new Modules.Spider());
        register(new Modules.Strafe());

        register(new Modules.FastPlace());
        register(new Modules.FastBreak());
        register(new Modules.InventorySweep());
        register(new Modules.AutoEat());

        register(new Modules.ESP());
        register(new Modules.Nametags());
        register(new Modules.BlockESP());
        register(new Modules.Fullbright());
        register(new Modules.Chams());
        register(new Modules.OldAnimations());

        register(new Modules.Timer());
        register(new Modules.PacketManipulation());
    }

    private void register(Module module) {
        modules.add(module);
    }

    public Module get(String name) {
        for (Module module : modules) {
            if (module.name.equalsIgnoreCase(name)) return module;
        }
        return null;
    }

    public List<Module> byCategory(Category category) {
        List<Module> list = new ArrayList<>();
        for (Module module : modules) {
            if (module.category == category) list.add(module);
        }
        return list;
    }
}
