package com.ollie.client.mixin;

import com.ollie.client.OllieClient;
import net.minecraft.client.renderer.ItemRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemRenderer.class)
public class MixinItemRenderer {

    @Shadow private float equippedProgress;
    @Shadow private float prevEquippedProgress;

    @Inject(method = "updateEquippedItem", at = @At("TAIL"))
    private void ollie$oldEquipAnimation(CallbackInfo ci) {
        if (OllieClient.isEnabled("1.7 Animations")) {
            this.equippedProgress = 1.0F;
            this.prevEquippedProgress = 1.0F;
        }
    }
}
