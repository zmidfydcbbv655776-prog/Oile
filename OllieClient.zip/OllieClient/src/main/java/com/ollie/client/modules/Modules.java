package com.ollie.client.modules;

import com.ollie.client.OllieClient;
import com.ollie.client.module.Category;
import com.ollie.client.module.Module;
import com.ollie.client.module.Setting;
import com.ollie.client.util.RenderUtils;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.network.play.client.C0FPacketConfirmTransaction;
import net.minecraft.util.BlockPos;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Mouse;

import java.lang.reflect.Field;

public final class Modules {

    private static final Minecraft mc = Minecraft.getMinecraft();

    private Modules() {}

    // COMBAT

    public static final class Aimbot extends Module {

        private final Setting.Num range = add(new Setting.Num("Range", 4.2f, 3f, 6f));
        private final Setting.Num speed = add(new Setting.Num("Speed", 38f, 5f, 100f));
        private final Setting.Bool autoFire = add(new Setting.Bool("Auto Fire", true));

        private EntityLivingBase target;
        private int attackDelay;

        public Aimbot() {
            super("Aimbot", "Locks rotation to nearest living target.", Category.COMBAT);
        }

        @SubscribeEvent
        public void onTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END || mc.thePlayer == null || mc.theWorld == null) return;

            target = findTarget();
            if (target == null) return;

            float[] rot = rotationsTo(target);
            mc.thePlayer.rotationYaw = smooth(mc.thePlayer.rotationYaw, rot[0], speed.value);
            mc.thePlayer.rotationPitch = smooth(mc.thePlayer.rotationPitch, rot[1], speed.value);

            if (autoFire.value && attackDelay-- <= 0) {
                mc.playerController.attackEntity(mc.thePlayer, target);
                mc.thePlayer.swingItem();
                attackDelay = 2;
            }
        }

        private EntityLivingBase findTarget() {
            EntityLivingBase best = null;
            double bestDist = range.value;

            for (Object obj : mc.theWorld.loadedEntityList) {
                if (!(obj instanceof EntityLivingBase)) continue;
                EntityLivingBase entity = (EntityLivingBase) obj;
                if (entity == mc.thePlayer || !entity.isEntityAlive()) continue;
                if (entity instanceof EntityPlayer && AntiBot.isBot(entity)) continue;

                double dist = mc.thePlayer.getDistanceToEntity(entity);
                if (dist < bestDist) {
                    bestDist = dist;
                    best = entity;
                }
            }
            return best;
        }

        private float[] rotationsTo(EntityLivingBase entity) {
            double dx = entity.posX - mc.thePlayer.posX;
            double dz = entity.posZ - mc.thePlayer.posZ;
            double dy = (entity.posY + entity.getEyeHeight())
                - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());

            double dist = Math.sqrt(dx * dx + dz * dz);
            float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
            float pitch = (float) (-Math.toDegrees(Math.atan2(dy, dist)));
            return new float[]{yaw, pitch};
        }

        private float smooth(float current, float target, float factor) {
            float delta = wrap(target - current);
            float step = Math.max(-factor, Math.min(factor, delta));
            return current + step;
        }

        private float wrap(float angle) {
            while (angle > 180f) angle -= 360f;
            while (angle < -180f) angle += 360f;
            return angle;
        }
    }

    public static final class AutoClicker extends Module {

        private final Setting.Num cps = add(new Setting.Num("CPS", 10f, 1f, 20f));
        private final Setting.Bool weaponsOnly = add(new Setting.Bool("Weapons Only", false));

        private int delay;

        public AutoClicker() {
            super("AutoClicker", "Clicks at a configured rate.", Category.COMBAT);
        }

        @SubscribeEvent
        public void onTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END || mc.currentScreen != null || mc.thePlayer == null) return;
            if (!Mouse.isButtonDown(0)) return;
            if (weaponsOnly.value && !isWeapon(mc.thePlayer.getHeldItem())) return;

            if (delay-- > 0) return;
            delay = Math.max(1, (int) (20f / cps.value));

            if (mc.objectMouseOver != null && mc.objectMouseOver.entityHit != null) {
                mc.playerController.attackEntity(mc.thePlayer, mc.objectMouseOver.entityHit);
            }
            mc.thePlayer.swingItem();
        }

        private boolean isWeapon(ItemStack stack) {
            if (stack == null) return false;
            String name = stack.getItem().getClass().getSimpleName().toLowerCase();
            return name.contains("sword") || name.contains("axe");
        }
    }

    public static final class Velocity extends Module {

        private final Setting.Num horizontal = add(new Setting.Num("Horizontal", 0.25f, 0f, 1f));
        private final Setting.Num vertical = add(new Setting.Num("Vertical", 0.25f, 0f, 1f));

        public Velocity() {
            super("Velocity", "Reduces incoming knockback.", Category.COMBAT);
        }

        @SubscribeEvent
        public void onTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END || mc.thePlayer == null) return;
            if (mc.thePlayer.maxHurtTime <= 0 || mc.thePlayer.hurtTime != mc.thePlayer.maxHurtTime) return;

            mc.thePlayer.motionX *= horizontal.value;
            mc.thePlayer.motionZ *= horizontal.value;
            mc.thePlayer.motionY *= vertical.value;
        }
    }

    public static final class Reach extends Module {

        private final Setting.Num distance = add(new Setting.Num("Distance", 4.5f, 3f, 6f));
        private float original = 4.5f;
        private boolean captured;

        public Reach() {
            super("Reach", "Extends block and entity interaction range.", Category.COMBAT);
        }

        @Override
        protected void onEnable() {
            try {
                Field field = mc.playerController.getClass().getDeclaredField("blockReachDistance");
                field.setAccessible(true);
                original = field.getFloat(mc.playerController);
                captured = true;
                field.setFloat(mc.playerController, distance.value);
            } catch (Exception ignored) {
            }
        }

        @Override
        protected void onDisable() {
            if (!captured) return;
            try {
                Field field = mc.playerController.getClass().getDeclaredField("blockReachDistance");
                field.setAccessible(true);
                field.setFloat(mc.playerController, original);
            } catch (Exception ignored) {
            }
        }
    }

    public static final class Criticals extends Module {

        private final Setting.Mode mode = add(new Setting.Mode("Mode", "Jump", "Jump", "Packet"));

        public Criticals() {
            super("Criticals", "Forces critical hits.", Category.COMBAT);
        }

        @SubscribeEvent
        public void onTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END || mc.thePlayer == null) return;
            if (!Mouse.isButtonDown(0)) return;
            if (mc.objectMouseOver == null || mc.objectMouseOver.entityHit == null) return;

            if (mode.value.equals("Jump")) {
                if (mc.thePlayer.onGround) mc.thePlayer.jump();
            } else {
                mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(
                    mc.thePlayer.posX, mc.thePlayer.posY + 0.0625, mc.thePlayer.posZ, false));
            }
        }
    }

    public static final class AntiBot extends Module {

        public AntiBot() {
            super("AntiBot", "Filters NPCs and fake players.", Category.COMBAT);
        }

        public static boolean isBot(net.minecraft.entity.Entity entity) {
            if (!(entity instanceof EntityPlayer)) return false;
            EntityPlayer player = (EntityPlayer) entity;
            if (player == mc.thePlayer) return false;
            if (player.isInvisible()) return true;

            String display = player.getDisplayName().getUnformattedText();
            if (display.contains("[NPC]") || display.contains("CIT-")) return true;

            String name = player.getName();
            return name.startsWith("§") || name.contains(" ");
        }
    }

    // MOVEMENT

    public static final class Speed extends Module {

        private final Setting.Num multiplier = add(new Setting.Num("Multiplier", 1.18f, 1.0f, 2.0f));

        public Speed() {
            super("Speed", "Increases ground movement speed.", Category.MOVEMENT);
        }

        @SubscribeEvent
        public void onTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END || mc.thePlayer == null) return;
            if (!mc.thePlayer.onGround) return;
            if (mc.thePlayer.moveForward == 0 && mc.thePlayer.moveStrafing == 0) return;

            mc.thePlayer.motionX *= multiplier.value;
            mc.thePlayer.motionZ *= multiplier.value;
        }
    }

    public static final class LongJump extends Module {

        private final Setting.Num boost = add(new Setting.Num("Boost", 1.8f, 1.0f, 3.0f));

        public LongJump() {
            super("LongJump", "Extends jump distance.", Category.MOVEMENT);
        }

        @SubscribeEvent
        public void onTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END || mc.thePlayer == null) return;
            if (!mc.gameSettings.keyBindJump.isKeyDown()) return;
            if (!mc.thePlayer.onGround) return;

            mc.thePlayer.motionY = 0.42;
            mc.thePlayer.motionX *= boost.value;
            mc.thePlayer.motionZ *= boost.value;
        }
    }

    public static final class HighJump extends Module {

        private final Setting.Num height = add(new Setting.Num("Height", 1.4f, 1.0f, 3.0f));

        public HighJump() {
            super("HighJump", "Increases jump height.", Category.MOVEMENT);
        }

        @SubscribeEvent
        public void onTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END || mc.thePlayer == null) return;
            if (!mc.gameSettings.keyBindJump.isKeyDown()) return;
            if (!mc.thePlayer.onGround) return;

            mc.thePlayer.motionY = 0.42 * height.value;
        }
    }

    public static final class Flight extends Module {

        private final Setting.Num speed = add(new Setting.Num("Speed", 0.7f, 0.1f, 2.0f));

        public Flight() {
            super("Flight", "Vanilla-free vertical and horizontal flight.", Category.MOVEMENT);
        }

        @SubscribeEvent
        public void onTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END || mc.thePlayer == null) return;

            double yaw = Math.toRadians(mc.thePlayer.rotationYaw);
            double forward = mc.thePlayer.moveForward;
            double strafe = mc.thePlayer.moveStrafing;

            mc.thePlayer.motionX = (-Math.sin(yaw) * forward + Math.cos(yaw) * strafe) * speed.value;
            mc.thePlayer.motionZ = (Math.cos(yaw) * forward + Math.sin(yaw) * strafe) * speed.value;

            if (mc.gameSettings.keyBindJump.isKeyDown()) {
                mc.thePlayer.motionY = speed.value;
            } else if (mc.gameSettings.keyBindSneak.isKeyDown()) {
                mc.thePlayer.motionY = -speed.value;
            } else {
                mc.thePlayer.motionY = 0;
            }

            mc.thePlayer.onGround = true;
        }
    }

    public static final class NoFall extends Module {

        public NoFall() {
            super("NoFall", "Prevents fall damage.", Category.MOVEMENT);
        }

        @SubscribeEvent
        public void onTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END || mc.thePlayer == null) return;
            if (mc.thePlayer.fallDistance <= 2f) return;

            mc.thePlayer.fallDistance = 0f;
            mc.getNetHandler().addToSendQueue(new C03PacketPlayer(true));
        }
    }

    public static final class Spider extends Module {

        private final Setting.Num climbSpeed = add(new Setting.Num("Climb Speed", 0.2f, 0.1f, 0.6f));

        public Spider() {
            super("Spider", "Climbs walls while colliding horizontally.", Category.MOVEMENT);
        }

        @SubscribeEvent
        public void onTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END || mc.thePlayer == null) return;
            if (!mc.thePlayer.isCollidedHorizontally) return;

            mc.thePlayer.motionY = climbSpeed.value;
        }
    }

    public static final class Strafe extends Module {

        public Strafe() {
            super("Strafe", "Automatically strafes while moving forward.", Category.MOVEMENT);
        }

        @SubscribeEvent
        public void onTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END || mc.thePlayer == null) return;
            if (!mc.thePlayer.onGround || mc.thePlayer.moveForward == 0) return;

            mc.thePlayer.movementInput.moveStrafe = 1f;
        }
    }

    // PLAYER

    public static final class FastPlace extends Module {

        public FastPlace() {
            super("FastPlace", "Removes right-click delay.", Category.PLAYER);
        }

        @SubscribeEvent
        public void onTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END || mc.currentScreen != null) return;
            mc.rightClickDelayTimer = 0;
        }
    }

    public static final class FastBreak extends Module {

        public FastBreak() {
            super("FastBreak", "Removes block break delay.", Category.PLAYER);
        }

        @SubscribeEvent
        public void onTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END || mc.playerController == null) return;
            mc.playerController.blockHitDelay = 0;
            mc.leftClickCounter = 0;
        }
    }

    public static final class InventorySweep extends Module {

        private final Setting.Bool auto = add(new Setting.Bool("Auto", true));
        private final Setting.Num delay = add(new Setting.Num("Delay", 4f, 1f, 20f));

        private int timer;

        public InventorySweep() {
            super("InventorySweep", "Drops junk items from inventory.", Category.PLAYER);
        }

        @SubscribeEvent
        public void onTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END || mc.thePlayer == null) return;
            if (auto.value && timer-- > 0) return;
            timer = delay.value.intValue();

            for (int slot = 0; slot < 36; slot++) {
                ItemStack stack = mc.thePlayer.inventory.getStackInSlot(slot);
                if (stack == null || !isJunk(stack)) continue;
                int containerSlot = slot < 9 ? slot + 36 : slot;
                mc.playerController.windowClick(0, containerSlot, 1, 4, mc.thePlayer);
                break;
            }
        }

        private boolean isJunk(ItemStack stack) {
            String name = stack.getDisplayName().toLowerCase();
            return name.contains("rotten flesh")
                || name.contains("poisonous potato")
                || name.contains("spider eye")
                || name.contains("pufferfish")
                || name.contains("bowl")
                || name.contains("stick");
        }
    }

    public static final class AutoEat extends Module {

        private final Setting.Num hunger = add(new Setting.Num("Hunger", 18f, 1f, 20f));

        public AutoEat() {
            super("AutoEat", "Eats food when hunger is low.", Category.PLAYER);
        }

        @SubscribeEvent
        public void onTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END || mc.thePlayer == null) return;

            if (mc.thePlayer.getFoodStats().getFoodLevel() >= hunger.value.intValue()) {
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
                return;
            }

            int foodSlot = findFoodSlot();
            if (foodSlot == -1) return;

            if (foodSlot < 9) {
                mc.thePlayer.inventory.currentItem = foodSlot;
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), true);
            }
        }

        private int findFoodSlot() {
            for (int i = 0; i < 9; i++) {
                ItemStack stack = mc.thePlayer.inventory.getStackInSlot(i);
                if (stack != null && stack.getItem() instanceof ItemFood) return i;
            }
            return -1;
        }
    }

    // RENDER

    public static final class ESP extends Module {

        private final Setting.Num red = add(new Setting.Num("Red", 0.75f, 0f, 1f));
        private final Setting.Num green = add(new Setting.Num("Green", 0.35f, 0f, 1f));
        private final Setting.Num blue = add(new Setting.Num("Blue", 1f, 0f, 1f));

        public ESP() {
            super("ESP", "Draws boxes around players.", Category.RENDER);
        }

        @SubscribeEvent
        public void onRender(RenderWorldLastEvent event) {
            if (mc.theWorld == null) return;
            int color = argb(255, red.value, green.value, blue.value);

            for (Object obj : mc.theWorld.playerEntities) {
                EntityPlayer player = (EntityPlayer) obj;
                if (player == mc.thePlayer) continue;
                if (AntiBot.isBot(player)) continue;
                RenderUtils.drawBox(player, color);
            }
        }
    }

    public static final class Nametags extends Module {

        private final Setting.Bool health = add(new Setting.Bool("Health", true));

        public Nametags() {
            super("Nametags", "Draws enhanced nametags through walls.", Category.RENDER);
        }

        @SubscribeEvent
        public void onRender(RenderWorldLastEvent event) {
            if (mc.theWorld == null) return;

            for (Object obj : mc.theWorld.playerEntities) {
                EntityPlayer player = (EntityPlayer) obj;
                if (player == mc.thePlayer) continue;
                if (AntiBot.isBot(player)) continue;

                String text = player.getName();
                if (health.value) {
                    text += " §c" + (int) player.getHealth();
                }

                RenderUtils.drawNametag(
                    text,
                    player.posX - mc.getRenderManager().viewerPosX,
                    player.posY + player.height + 0.4 - mc.getRenderManager().viewerPosY,
                    player.posZ - mc.getRenderManager().viewerPosZ,
                    0xFFFFFFFF
                );
            }
        }
    }

    public static final class BlockESP extends Module {

        private final Setting.Num radius = add(new Setting.Num("Radius", 24f, 8f, 48f));
        private final Setting.Mode block = add(new Setting.Mode(
            "Block", "Chest",
            "Chest", "Ender Chest", "Furnace", "Spawner", "Diamond Ore", "Gold Ore"
        ));

        public BlockESP() {
            super("BlockESP", "Highlights selected blocks nearby.", Category.RENDER);
        }

        @SubscribeEvent
        public void onRender(RenderWorldLastEvent event) {
            if (mc.theWorld == null || mc.thePlayer == null) return;

            Block target = resolveBlock();
            int r = radius.value.intValue();
            BlockPos origin = new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ);

            for (int x = -r; x <= r; x++) {
                for (int y = -r; y <= r; y++) {
                    for (int z = -r; z <= r; z++) {
                        BlockPos pos = origin.add(x, y, z);
                        if (mc.theWorld.getBlockState(pos).getBlock() == target) {
                            RenderUtils.drawBlockBox(pos, 0xFF44DDFF);
                        }
                    }
                }
            }
        }

        private Block resolveBlock() {
            switch (block.value) {
                case "Ender Chest": return Blocks.ender_chest;
                case "Furnace": return Blocks.furnace;
                case "Spawner": return Blocks.mob_spawner;
                case "Diamond Ore": return Blocks.diamond_ore;
                case "Gold Ore": return Blocks.gold_ore;
                default: return Blocks.chest;
            }
        }
    }

    public static final class Fullbright extends Module {

        private float originalGamma;

        public Fullbright() {
            super("Fullbright", "Maximum gamma brightness.", Category.RENDER);
        }

        @Override
        protected void onEnable() {
            originalGamma = mc.gameSettings.gammaSetting;
            mc.gameSettings.gammaSetting = 100f;
        }

        @Override
        protected void onDisable() {
            mc.gameSettings.gammaSetting = originalGamma;
        }
    }

    public static final class Chams extends Module {
        public Chams() {
            super("Chams", "Renders entities through walls via mixin.", Category.RENDER);
        }
    }

    public static final class OldAnimations extends Module {
        public OldAnimations() {
            super("1.7 Animations", "Old equip and swing animation via mixin.", Category.RENDER);
        }
    }

    // MISC

    public static final class Timer extends Module {

        private final Setting.Num speed = add(new Setting.Num("Speed", 1.2f, 0.1f, 5f));

        public Timer() {
            super("Timer", "Changes client tick speed.", Category.MISC);
        }

        @Override
        protected void onEnable() {
            mc.timer.timerSpeed = speed.value;
        }

        @Override
        protected void onDisable() {
            mc.timer.timerSpeed = 1f;
        }
    }

    public static final class PacketManipulation extends Module {

        private final Setting.Bool c03 = add(new Setting.Bool("C03 Player", false));
        private final Setting.Bool c0f = add(new Setting.Bool("C0F Transaction", false));
        private final Setting.Bool c0b = add(new Setting.Bool("C0B Action", false));
        private final Setting.Bool c0a = add(new Setting.Bool("C0A Animation", false));

        public PacketManipulation() {
            super("PacketManipulation", "Cancels selected outgoing packets.", Category.MISC);
        }

        public static boolean shouldCancel(Packet<?> packet) {
            Module module = OllieClient.moduleManager == null
                ? null
                : OllieClient.moduleManager.get("PacketManipulation");
            if (module == null || !module.enabled) return false;

            PacketManipulation self = (PacketManipulation) module;
            if (self.c03.value && packet instanceof C03PacketPlayer) return true;
            if (self.c0f.value && packet instanceof C0FPacketConfirmTransaction) return true;
            if (self.c0b.value && packet instanceof C0BPacketEntityAction) return true;
            if (self.c0a.value && packet instanceof C0APacketAnimation) return true;
            return false;
        }
    }

    private static int argb(int alpha, float r, float g, float b) {
        return ((int) (alpha * 255) << 24)
            | ((int) (r * 255) << 16)
            | ((int) (g * 255) << 8)
            | (int) (b * 255);
    }
}
