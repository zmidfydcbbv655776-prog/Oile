package com.ollie.client.mixin;

import com.ollie.client.OllieClient;
import net.minecraft.client.renderer.entity.RendererLivingEntity;
import net.minecraft.entity.EntityLivingBase;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(RendererLivingEntity.class)
public class MixinRendererLivingEntity {

    @Inject(method = "doRender", at = @At("HEAD"))
    private void ollie$chamsPre(EntityLivingBase entity, double x, double y, double z,
                                float entityYaw, float partialTicks, CallbackInfo ci) {
        if (!OllieClient.isEnabled("Chams")) return;
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(0.7f, 0.35f, 1.0f, 0.55f);
    }

    @Inject(method = "doRender", at = @At("RETURN"))
    private void ollie$chamsPost(EntityLivingBase entity, double x, double y, double z,
                                 float entityYaw, float partialTicks, CallbackInfo ci) {
        if (!OllieClient.isEnabled("Chams")) return;
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glColor4f(1f, 1f, 1f, 1f);
    }
}
